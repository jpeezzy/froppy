#ifndef _DATA_BASE_H
#define _DATA_BASE_H

// struct representing a database of information extracted from fen file

#endif