#ifndef _BASIC_EVAL_H
#define _BASIC_EVAL_H
#include "boardstate.h"

int basicEvaluation(BSTATE* currentboard);

#endif
