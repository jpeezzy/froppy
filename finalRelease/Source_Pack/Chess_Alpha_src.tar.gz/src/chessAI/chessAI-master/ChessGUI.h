#ifndef CHESSGUI_H
#define CHESSGUI_H

void GUI(int barr[8][8]);

#endif 
