# chessAI
this chess program is for boosted animals only,
test
