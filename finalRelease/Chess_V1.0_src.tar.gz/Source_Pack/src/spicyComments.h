#ifndef _SPICY_COMMENTS_H
#define _SPICY_COMMENTS_H
#include "movelist.h"

// evaluate the move of the users based on the eval function 
// of the difficulty

void spicyAdd(BSTATE*);

#endif