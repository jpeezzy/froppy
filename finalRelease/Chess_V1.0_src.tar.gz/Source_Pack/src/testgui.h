#ifndef TESTGUI_H
#define TESTGUI_H

void GUI(int barr[8][8]);

#endif 
