/** file: board to vector:
 * Author: Justin Lee
 * here is a function to go from board structure to
 * a 1x774 (5+2*6*64)
 *
 *
 */
#ifndef BOARDSTATE_H
#define BOARDSTATE_H
#include "boardstate.h"
void boardToVector(BSTATE *board, double *vector);
#endif
