#ifndef _BASIC_EVAL_H
#define _BASIC_EVAL_H
#include "boardstate.h"

float basicEvaluation(BSTATE* currentboard);

#endif
