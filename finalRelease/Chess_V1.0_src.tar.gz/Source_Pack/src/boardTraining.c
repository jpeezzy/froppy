#include "boardstate.h"
#include "boardTraining.h"
#include "dataEntry.h"
#include "randGen.h"



