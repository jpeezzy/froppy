#ifndef _USER_HINT_H
#define _USER_HINT_H

#include "movelist.h"
#include "boardstate.h"
#include "SDL/SDL.h"

void giveHint(BSTATE *board, SDL_Surface *LoadingHint, SDL_Surface *screen);

#endif
